"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deactivate = exports.activate = void 0;
const utils_1 = require("./utils");
const panel_manager_1 = require("./panel-manager");
const webview_msg_handler_1 = require("./webview-msg-handler");
function activate(context) {
    // 响应VSCode配置修改
    utils_1.Utils.addConfigListening();
    // 清除Vscode缓存信息
    utils_1.Utils.initVscodeCache(context, true);
    // 响应perfadvisor左侧菜单树所有按钮的命令来打开不同的webview
    // console.log('here')
    webview_msg_handler_1.messageHandler.reloadConfigurations(context);
    panel_manager_1.ToolPanelManager.createOrShowPanelForPerfCommand(context);
    // const sidebar_test = new sidebar.TreeViewProvider();
    // vscode.window.registerTreeDataProvider("perfadvisorTools", sidebar_test);
    // vscode.commands.executeCommand('setContext', 'ipconfig', true);
    // const provider = new SideViewProvider(context.extensionUri);
    // context.subscriptions.push(
    //     vscode.window.registerWebviewViewProvider(SideViewProvider.viewType, provider));
}
exports.activate = activate;
function deactivate() {
}
exports.deactivate = deactivate;
//# sourceMappingURL=extension.js.map