"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProxyManager = void 0;
const httpProxy = require('http-proxy');
const cProcess = require('child_process');
class ProxyManager {
    /**
     * 判断端口是否被占用
     * @param port 端口号
     * @returns 该端口是否被占用
     */
    static isPortOpen(port) {
        const order = `netstat -ano|findstr "${port}"`;
        return new Promise((resolve, reject) => {
            cProcess.exec(order, (error, stdout, stderr) => {
                if (stdout === '') {
                    resolve(false);
                }
                else {
                    resolve(true);
                }
            });
        });
    }
    /**
     * 创建代理服务
     * @returns Promise<>
     */
    static async createProxyServer(context, ip, port) {
        const sessionDefaultPort = context.globalState.get('defaultPort');
        let proxyServerPort = sessionDefaultPort
            ? Number(sessionDefaultPort)
            : 3661;
        const resFlag = await ProxyManager.isPortOpen(proxyServerPort);
        if (resFlag) {
            proxyServerPort += 1;
        }
        const target = `https://${ip}:${port}`;
        const config = {
            target,
            xfwd: false,
            selfHandleResponse: false,
            secure: false,
            changeOrigin: true,
            ws: true
        };
        const proxy = httpProxy.createProxyServer(config).listen(proxyServerPort);
        proxy.on('proxyRes', (proxyRes, req, res) => {
            const newRes = {};
            let index = proxyRes.rawHeaders.indexOf('token');
            let authValue = '';
            if (index !== -1) {
                const token = 'token';
                authValue = proxyRes.rawHeaders[index + 1];
                newRes[token] = authValue;
                ProxyManager.authValue = authValue;
            }
            index = proxyRes.rawHeaders.indexOf('Content-Type');
            if (index !== -1) {
                newRes['Content-Type'] = proxyRes.rawHeaders[index + 1];
            }
            const statusCode = proxyRes.statusCode;
            res.writeHead(statusCode, newRes);
        });
        return Promise.resolve({ proxyServerPort, proxy });
    }
}
exports.ProxyManager = ProxyManager;
//# sourceMappingURL=proxy-manager.js.map