"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VIEW_TYPE = exports.PANEL_ID = void 0;
/**
 * webview panel ID
 */
var PANEL_ID;
(function (PANEL_ID) {
    PANEL_ID["tuningNonServerConfig"] = "tuningNonServerConfig";
    PANEL_ID["tuningFreeTrialRemoteEnvironment"] = "tuningFreeTrialRemoteEnvironment";
    PANEL_ID["tuningUninstall"] = "tuningUninstall";
    PANEL_ID["tuningInstall"] = "tuningInstall";
    PANEL_ID["tuningUpgrade"] = "tuningUpgrade";
    PANEL_ID["tuningNonLogin"] = "tuningNonLogin";
    PANEL_ID["tuningErrorInstruction"] = "tuningErrorInstruction";
    PANEL_ID["tuningGuide"] = "tuningConfigGuide";
})(PANEL_ID = exports.PANEL_ID || (exports.PANEL_ID = {}));
/**
 * webview 类型
 */
var VIEW_TYPE;
(function (VIEW_TYPE) {
    VIEW_TYPE["serverConfig"] = "serverConfig";
    VIEW_TYPE["freeTrialRemoteEnvironment"] = "freeTrialRemoteEnvironment";
    VIEW_TYPE["uninstall"] = "uninstall";
    VIEW_TYPE["install"] = "install";
    VIEW_TYPE["upgrade"] = "upgrade";
    VIEW_TYPE["serverError"] = "serverError";
    VIEW_TYPE["login"] = "login";
    VIEW_TYPE["guide"] = "guide";
})(VIEW_TYPE = exports.VIEW_TYPE || (exports.VIEW_TYPE = {}));
//# sourceMappingURL=constant.js.map