"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.messageHandler = void 0;
const vscode = require("vscode");
const utils_1 = require("./utils");
const panel_manager_1 = require("./panel-manager");
const i18nservice_1 = require("./i18nservice");
const ssh2Tools_1 = require("./ssh2Tools");
const error_helper_1 = require("./error-helper");
const proxy_manager_1 = require("./proxy-manager");
const SideViewProvider_1 = require("./SideView/SideViewProvider");
const fs = require('fs');
const i18n = i18nservice_1.I18nService.I18n();
let terminalStatusInterval;
let terminalCloseEvent;
var currentSideViewProvider;
var currentSideViewProviderHandler;
var isRegistered = false;
exports.messageHandler = {
    // 从配置文件读取ip与port
    readConfig(global, message) {
        const json = utils_1.Utils.getConfigJson(global.context);
        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, json);
    },
    // 从配置文件读取url
    readUrlConfig(global, message) {
        const json = utils_1.Utils.getURLConfigJson(global.context);
        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, json);
    },
    // 保存ip与port到json配置文件
    async saveConfig(global, message) {
        // if (!message.data.openConfigServer) {  // 点击弹窗中的是openConfigServer为true
        //     if (ToolPanelManager.loginPanels.length > 0) {
        //         // 弹窗提示是否切换服务器
        //         const panel = global.toolPanel.getPanel();
        //         panel.webview.postMessage({ cmd: 'handleVscodeMsg', type: 'showCustomDialog', data: { show: true } });
        //         return;
        //     }
        // }
        let tuningConfig;
        try {
            tuningConfig = JSON.parse(message.data.data).portConfig;
        }
        catch (err) {
            tuningConfig = {};
        }
        const tuningConfigObj = Array.isArray(tuningConfig) ? tuningConfig[0] : tuningConfig;
        console.log("tuningConfigObj is: ", tuningConfigObj);
        let data;
        global.context.globalState.update('tuningIp', tuningConfigObj.ip);
        global.context.globalState.update('tuningPort', tuningConfigObj.port);
        const { proxyServerPort, proxy } = await proxy_manager_1.ProxyManager.createProxyServer(global.context, tuningConfigObj.ip, tuningConfigObj.port);
        global.context.globalState.update('defaultPort', proxyServerPort);
        const queryVersionOptions = {
            url: `http://127.0.0.1:${proxyServerPort}/user-management/api/v2.2/users/version/`,
            method: 'GET'
        };
        const respVersion = await utils_1.Utils.requestData(global.context, queryVersionOptions, message.module);
        if (respVersion.status === 200 /* HTTP_200_OK */) {
            const serverVersion = respVersion?.data?.data?.version;
            if (!utils_1.Utils.checkVersion(global.context, serverVersion)) {
                proxy.close();
                const configVersion = utils_1.Utils.getConfigJson(global.context).configVersion[0];
                // 版本不匹配
                data = { type: 'VERSIONMISMATCH', configVersion, serverVersion };
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data);
                return;
            }
            const queryOptions = {
                url: `http://127.0.0.1:${proxyServerPort}/user-management/api/v2.2/users/admin-status/`,
                method: 'GET'
            };
            const resp = await utils_1.Utils.requestData(global.context, queryOptions, message.module);
            if (resp.status === 200 /* HTTP_200_OK */) {
                vscode.commands.executeCommand('setContext', 'ipconfig', true);
                vscode.commands.executeCommand('setContext', 'isPerfadvisorConfigured', true);
                global.context.globalState.update('ipConfig', true);
                data = { type: 'SUCCESS' };
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data);
                panel_manager_1.ToolPanelManager.closeLoginPanel();
                if (message.data.openLogin) {
                    utils_1.Utils.navToIFrame(global, proxyServerPort, proxy);
                }
                if (isRegistered) {
                    currentSideViewProviderHandler.dispose();
                }
                const provider = new SideViewProvider_1.SideViewProvider(global.context.extensionUri);
                currentSideViewProvider = provider;
                let previous_dispose_handler = vscode.window.registerWebviewViewProvider(SideViewProvider_1.SideViewProvider.viewType, provider);
                isRegistered = true;
                currentSideViewProviderHandler = previous_dispose_handler;
                const resourcePath = utils_1.Utils.getExtensionFileAbsolutePath(global.context, 'out/assets/config.json');
                data = fs.writeFileSync(resourcePath, message.data.data);
                this.updateIpAndPort(global.context, provider);
                vscode.commands.executeCommand('setContext', 'isPerfadvisorConfigured', false);
                vscode.commands.executeCommand('setContext', 'isPerfadvisorConfigured', true);
                vscode.commands.executeCommand('setContext', 'isPerfadvisorLoggedInJustClosed', false);
            }
            else {
                data = { type: 'FAIL' };
                proxy.close();
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data);
            }
        }
        else {
            data = { type: 'FAIL' };
            proxy.close();
            utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data);
        }
    },
    /**
     * 更新ip与端口的显示内容
     * @param originalContent 更新之前的
     */
    updateIpAndPort(context, provider) {
        let newConfigPath = utils_1.Utils.getExtensionFileAbsolutePath(context, 'out/assets/config.json');
        let data = JSON.parse(fs.readFileSync(newConfigPath));
        // console.log(data.tuningConfig[0].ip);
        var new_ip = data.portConfig[0].ip;
        var new_port = data.portConfig[0].port;
        provider.updateServerConfiguration(new_ip, new_port);
        // SideViewProvider.
    },
    /**
     * 登录指令请求跳转登录页面
     * @param global global
     * @param message message
     */
    async openLoginByButton(global) {
        const resourcePath = utils_1.Utils.getExtensionFileAbsolutePath(global.context, 'out/assets/config.json');
        const configData = fs.readFileSync(resourcePath);
        let tuningConfig;
        try {
            tuningConfig = JSON.parse(configData).portConfig;
        }
        catch (err) {
            tuningConfig = {};
        }
        const tuningConfigObj = Array.isArray(tuningConfig) ? tuningConfig[0] : tuningConfig;
        // tslint:disable-next-line:max-line-length
        const { proxyServerPort, proxy } = await proxy_manager_1.ProxyManager.createProxyServer(global.context, tuningConfigObj.ip, tuningConfigObj.port);
        utils_1.Utils.navToIFrame(global, proxyServerPort, proxy);
        panel_manager_1.ToolPanelManager.closePanelsByRemained('tuning', []);
    },
    /**
     * 打开新的vscode窗口
     *
     * @param global 全局上下文
     * @param message 消息内容
     */
    openNewPage(global, message) {
        const session = {
            language: vscode.env.language
        };
        let navMessage;
        if ('message' in message.data) {
            navMessage = utils_1.Utils.generateMessage('navigate', {
                page: '/' + message.data.router, pageParams: { queryParams: message.data.message }, webSession: session
            });
        }
        else if (message.data.router === 'login') {
            // 利用openNewPage打开登录页
            exports.messageHandler.openLoginByButton(global);
            return;
        }
        else {
            navMessage = utils_1.Utils.generateMessage('navigate', {
                page: '/' + message.data.router, webSession: session
            });
        }
        const viewTitle = message.data.viewTitle;
        const panelOption = {
            panelId: message.data.panelId,
            viewType: message.data.viewType || message.module,
            viewTitle,
            module: message.module,
            message: navMessage,
        };
        panel_manager_1.ToolPanelManager.createOrShowPanel(panelOption, global.context);
    },
    // 关闭panel
    closePanel(global, message) {
        panel_manager_1.ToolPanelManager.closePanel(global.toolPanel.getPanelId(), message.module);
    },
    // 检查ssh连接是否通畅
    async checkConn(global, message) {
        const ssh2Tools = new ssh2Tools_1.SSH2Tools();
        const sshCheckResult = await ssh2Tools.sshClientCheck();
        if (!sshCheckResult) {
            utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'sshClientCheck');
            this.clearPwd(message.data.password);
            this.clearPwd(message.data.privateKey);
            return;
        }
        let server = {};
        if (message.data.sshType === 'usepwd') {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                password: message.data.password,
                hostHash: 'sha256',
                hostVerifier: (hashedKey, callback1) => {
                    const finger = utils_1.Utils.getConfigJson(global.context).hostVerifier;
                    const tempip = message.data.host;
                    utils_1.Utils.fingerCheck(global, tempip, hashedKey, finger).then((data) => {
                        callback1(true);
                    });
                }
            };
        }
        else {
            // 检测秘钥文件是否有秘钥短语
            if (!ssh2Tools.checkRealExistPassphrase(message.data)) {
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'USERAUTH_FAILURE');
                return;
            }
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                privateKey: fs.readFileSync(message.data.privateKey),
                passphrase: message.data.passphrase,
                hostHash: 'sha256',
                hostVerifier: (hashedKey, callback1) => {
                    const finger = utils_1.Utils.getConfigJson(global.context).hostVerifier;
                    const tempip = message.data.host;
                    utils_1.Utils.fingerCheck(global, tempip, hashedKey, finger).then((data) => {
                        callback1(true);
                    });
                }
            };
        }
        const callback = (data) => {
            if (data instanceof Error) {
                if (data.message.search(/ETIMEDOUT/) !== -1 || data.message.search(/ECONNREFUSED/) !== -1) {
                    error_helper_1.ErrorHelper.errorHandler(global.context, message.module, data.message, server.host);
                }
                else if (data.message.search(/no matching/) !== -1) {
                    utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data.toString());
                }
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data.toString());
            }
            else {
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data.toString());
            }
        };
        new ssh2Tools_1.SSH2Tools().connectTest(server, () => { }, callback);
        this.clearPwd(message.data.password);
        this.clearPwd(message.data.privateKey);
    },
    async readFinger(global, message) {
        const ssh2Tools = new ssh2Tools_1.SSH2Tools();
        const sshCheckResult = await ssh2Tools.sshClientCheck();
        var currentFinger;
        var fingerExist = false;
        if (!sshCheckResult) {
            utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'sshClientCheck');
            this.clearPwd(message.data.password);
            this.clearPwd(message.data.privateKey);
            return;
        }
        let server = {};
        if (message.data.sshType === 'usepwd') {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                password: message.data.password,
                hostHash: 'sha256',
                hostVerifier: (hashedKey, callback1) => {
                    currentFinger = hashedKey;
                    const tempip = message.data.host;
                    const finger = utils_1.Utils.getConfigJson(global.context).hostVerifier;
                    utils_1.Utils.fingerCheck(global, tempip, hashedKey, finger).then((data) => {
                        fingerExist = data;
                    });
                    callback1(true);
                }
            };
        }
        else {
            // 检测秘钥文件是否有秘钥短语
            if (!ssh2Tools.checkRealExistPassphrase(message.data)) {
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'USERAUTH_FAILURE');
                return;
            }
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                privateKey: fs.readFileSync(message.data.privateKey),
                passphrase: message.data.passphrase,
                hostHash: 'sha256',
                hostVerifier: (hashedKey, callback1) => {
                    currentFinger = hashedKey;
                    const tempip = message.data.host;
                    const finger = utils_1.Utils.getConfigJson(global.context).hostVerifier;
                    utils_1.Utils.fingerCheck(global, tempip, hashedKey, finger).then((data) => {
                        fingerExist = data;
                    });
                    callback1(true);
                }
            };
        }
        const callback = (data) => {
            console.log(data);
            if (data instanceof Error) {
                if (data.message.search(/ETIMEDOUT/) !== -1 || data.message.search(/ECONNREFUSED/) !== -1) {
                    error_helper_1.ErrorHelper.errorHandler(global.context, message.module, data.message, server.host);
                }
                else if (data.message.search(/no matching/) !== -1) {
                    vscode.window.showErrorMessage(i18n.plugins_common_message_sshAlgError);
                }
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'TIMEOUT');
            }
            else {
                if (data.search(/SUCCESS/) !== -1) {
                    if (fingerExist) {
                        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, "noFirst");
                    }
                    else {
                        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, currentFinger.toString());
                    }
                }
                else {
                    utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data.toString());
                }
            }
        };
        new ssh2Tools_1.SSH2Tools().connectTest(server, () => { }, callback);
        this.clearPwd(message.data.password);
        this.clearPwd(message.data.privateKey);
    },
    async saveFinger(global, message) {
        const tempip = message.data.ip;
        const tempfinger = message.data.finger;
        utils_1.Utils.savefinger(global, tempip, tempfinger).then((data) => {
            let response = '';
            if (data) {
                response = "SUCCESS";
            }
            else {
                response = "FAIL";
            }
            if (!utils_1.Utils.fingerLengthCheck(global)) {
                response = response.concat('_oversize');
            }
            utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, response);
        });
    },
    /**
     * 密码释放
     * @param message: 来自webview的消息内容
     */
    clearPwd(password) {
        password = '';
        password = '';
        password = '';
    },
    /**
     * webview侧发消息给vscode发消息需在右下角弹提醒框
     * @param global 插件上下文,以及当前的panel
     * @param message 来自webview的提示内容{info:弹框显示的信息, type:弹框级别,{error,info,warn}}
     */
    async showInfoBox(global, message) {
        utils_1.Utils.showMessageByType(message.data.type, { info: message.data.info }, true);
    },
    /**
     * 升级后台服务器
     *
     * @param global 全局上下文
     * @param message 消息内容
     */
    async upgrade(global, message) {
        let server = {};
        let terminal;
        const ssh2Tools = new ssh2Tools_1.SSH2Tools();
        if (message.data.sshType === 'usepwd') {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                password: message.data.password,
            };
        }
        else {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                privateKey: fs.readFileSync(message.data.privateKey),
                passphrase: message.data.passphrase
            };
        }
        // 流程处理回调函数
        const processHandler = (data) => {
            if (data instanceof Error) {
                message.module = 'tuning';
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'Error:' + data.toString());
            }
            else if (typeof data === 'string') {
                if (data.search(/success|failed/) !== -1) {
                    clearInterval(terminalStatusInterval);
                    if (terminalCloseEvent) {
                        terminalCloseEvent.dispose();
                    }
                    ssh2Tools.closeConnect();
                    if (data.search(/success/) !== -1) {
                        // 延迟1秒隐藏终端
                        setTimeout(() => { terminal.hide(); }, 1000);
                    }
                }
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data);
            }
        };
        // 建立连接
        await ssh2Tools.connect(server).catch(processHandler);
        message.module = 'sysPerf';
        // 上传脚本文件
        const timestamp = utils_1.Utils.formatDatetime(message.data.startUpgradeDatetime, 'yy_M_d_h_m_s');
        const workDir = '/tmp/vscode' + '_' + timestamp + '/';
        await ssh2Tools.mkdir(workDir, { mode: '700' }).catch(processHandler);
        const preShellName = 'upgrade_' + message.module + '.sh';
        const shellName = message.module + '_upgrade.sh';
        const preShellPromise = ssh2Tools.writeFile(preShellName, workDir + preShellName);
        const shellPromise = ssh2Tools.writeFile(shellName, workDir + shellName);
        await Promise.all([preShellPromise, shellPromise]).catch(processHandler);
        // 创建终端
        terminal = vscode.window.createTerminal();
        // 创建终端，关闭upgrade页面loading
        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'closeLoading');
        // 创建终端异常退出处理
        handleTerminalException(terminal, ssh2Tools, [workDir + preShellName, workDir + shellName], (clearError) => {
            const text = 'upgrade clear error: ' + clearError;
        }, processHandler);
        // 显示终端，开始部署
        terminal.show();
        terminal.sendText('ssh -t -p' + server.port + ' ' + server.username +
            '@' + server.host + ' bash ' + workDir + preShellName + ' -u ' + this.getUrl(global) +
            ' -c "' + this.getKeyUrl(global) + '" \n');
        // 查询是否部署完成
        const stepName = '.upgrade_' + message.module + '.step';
        ssh2Tools.tailFlow(workDir + stepName, processHandler).catch(processHandler);
        // 添加关闭连接前事件
        ssh2Tools.onCloseBefore = () => {
            return ssh2Tools.exec('rm -rf ' + workDir + stepName);
        };
        // 清除用户信息
        server = undefined;
        message.data.username = undefined;
        message.data.password = undefined;
    },
    /**
     * 安装后台服务器
     *
     * @param global 全局上下文
     * @param message 消息内容
     */
    async install(global, message) {
        let server = {};
        let terminal;
        const ssh2Tools = new ssh2Tools_1.SSH2Tools();
        if (message.data.sshType === 'usepwd') {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                password: message.data.password,
            };
        }
        else {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                privateKey: fs.readFileSync(message.data.privateKey),
                passphrase: message.data.passphrase
            };
        }
        // 流程处理回调函数
        const processHandler = (data) => {
            if (data instanceof Error) {
                message.module = 'tuning';
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'Error:' + data.toString());
            }
            else if (typeof data === 'string') {
                if (data.search(/success|failed/) !== -1) {
                    clearInterval(terminalStatusInterval);
                    if (terminalCloseEvent) {
                        terminalCloseEvent.dispose();
                    }
                    ssh2Tools.closeConnect();
                    if (data.search(/success/) !== -1) {
                        // 延迟1秒隐藏终端
                        setTimeout(() => { terminal.hide(); }, 1000);
                    }
                }
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data);
            }
        };
        // 建立连接
        await ssh2Tools.connect(server).catch(processHandler);
        message.module = 'sysPerf';
        // 上传脚本文件
        const timestamp = utils_1.Utils.formatDatetime(message.data.startInstallDatetime, 'yy_M_d_h_m_s');
        const workDir = '/tmp/vscode' + '_' + timestamp + '/';
        await ssh2Tools.mkdir(workDir, { mode: '700' }).catch(processHandler);
        const preShellName = 'deploy_' + message.module + '.sh';
        const shellName = 'write_' + message.module + '_log.sh';
        const preShellPromise = ssh2Tools.writeFile(preShellName, workDir + preShellName);
        const shellPromise = ssh2Tools.writeFile(shellName, workDir + shellName);
        await Promise.all([preShellPromise, shellPromise]).catch(processHandler);
        // 创建终端
        terminal = vscode.window.createTerminal();
        // 创建终端，关闭install页面loading
        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'closeLoading');
        // 创建终端异常退出处理
        handleTerminalException(terminal, ssh2Tools, [workDir + preShellName, workDir + shellName], (clearError) => {
            const text = 'install clear error: ' + clearError;
        }, processHandler);
        // 显示终端，开始部署
        terminal.show();
        terminal.sendText('ssh -t -p' + server.port + ' ' + server.username +
            '@' + server.host + ' bash ' + workDir + preShellName + ' -u ' + this.getUrl(global) +
            ' -c "' + this.getKeyUrl(global) + '" \n');
        // 查询是否部署完成
        const stepName = '.install_' + message.module + '.step';
        ssh2Tools.tailFlow(workDir + stepName, processHandler).catch(processHandler);
        // 添加关闭连接前事件
        ssh2Tools.onCloseBefore = () => {
            return ssh2Tools.exec('rm -rf ' + workDir + stepName);
        };
        // 清除用户信息
        server = undefined;
        message.data.username = undefined;
        message.data.password = undefined;
    },
    /**
     * 卸载后台服务器
     *
     * @param global 全局上下文
     * @param message 消息内容
     */
    async uninstall(global, message) {
        let server = {};
        let terminal;
        const ssh2Tools = new ssh2Tools_1.SSH2Tools();
        if (message.data.sshType === 'usepwd') {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                password: message.data.password,
            };
        }
        else {
            server = {
                host: message.data.host,
                port: message.data.port,
                username: message.data.username,
                privateKey: fs.readFileSync(message.data.privateKey),
                passphrase: message.data.passphrase
            };
        }
        // 流程处理回调函数
        const processHandler = (data) => {
            if (data instanceof Error) {
                message.module = 'tuning';
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'Error:' + data.toString());
            }
            else if (typeof data === 'string') {
                if (data.search(/success|failed/) !== -1) {
                    clearInterval(terminalStatusInterval);
                    if (terminalCloseEvent) {
                        terminalCloseEvent.dispose();
                    }
                    ssh2Tools.closeConnect();
                    if (data.search(/success/) !== -1) {
                        // 延迟1秒隐藏终端
                        setTimeout(() => { terminal.hide(); }, 1000);
                    }
                }
                utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, data);
            }
        };
        // 建立连接
        await ssh2Tools.connect(server).catch(processHandler);
        message.module = 'sysPerf';
        // 上传脚本文件
        const timestamp = utils_1.Utils.formatDatetime(message.data.startUninstallDatetime, 'yy_M_d_h_m_s');
        const workDir = '/tmp/vscode' + '_' + timestamp + '/';
        await ssh2Tools.mkdir(workDir, { mode: '700' }).catch(processHandler);
        const preShellName = 'uninstall_' + message.module + '.sh';
        const shellName = message.module + '_log.sh';
        const preShellPromise = ssh2Tools.writeFile(preShellName, workDir + preShellName);
        const shellPromise = ssh2Tools.writeFile(shellName, workDir + shellName);
        await Promise.all([preShellPromise, shellPromise]).catch(processHandler);
        // 创建终端
        terminal = vscode.window.createTerminal();
        // 创建终端，关闭uninstall页面loading
        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, 'closeLoading');
        handleTerminalException(terminal, ssh2Tools, [workDir + preShellName, workDir + shellName], (clearError) => {
            const text = 'uninstall clear error: ' + clearError;
        }, processHandler);
        // 显示终端，开始卸载
        terminal.show();
        terminal.sendText('ssh -t -p' + server.port + ' ' + server.username + '@' + server.host +
            ' bash ' + workDir + preShellName + ' \n');
        // 查询是否卸载完成
        const stepName = '.uninstall_' + message.module + '.step';
        ssh2Tools.tailFlow(workDir + stepName, processHandler).catch(processHandler);
        // 添加关闭连接前事件
        ssh2Tools.onCloseBefore = () => {
            return ssh2Tools.exec('rm -rf ' + workDir + stepName);
        };
        // 清除用户信息
        server = undefined;
        message.data.username = undefined;
        message.data.password = undefined;
    },
    /**
     * 获取安装包路径
     */
    getUrl(global) {
        return utils_1.Utils.getConfigJson(global.context).pkg_url;
    },
    /**
     * 获取KEY路径
     */
    getKeyUrl(global) {
        return utils_1.Utils.getConfigJson(global.context).key;
    },
    // 清理json配置文件中的ip和port
    async cleanConfig(global, message) {
        global.context.globalState.update('closeShowErrorMessage', true);
        utils_1.Utils.invokeCallback(global.toolPanel.getPanel(), message, { cleanOk: true });
        // 清空session缓存,并将新的配置更新到session中
        utils_1.Utils.initVscodeCache(global.context);
        // 关闭其他页面
        panel_manager_1.ToolPanelManager.closePanelsByRemained(message.module, [global.toolPanel.getPanelId()]);
        global.context.globalState.update(message.module + 'uploadProcessFlag', 0);
    },
    // 关闭所有panel
    closeAllPanel(global, message) {
        this.closePanel(global, message);
    },
    /**
     * 隐藏terminal
     * @param global: 插件上下文，以及当前的panel
     * @param message: 来自webview的消息内容
     */
    hideTerminal(global, message) {
        vscode.window.activeTerminal?.hide();
    }
};
function handleTerminalException(terminal, ssh2Tools, fileList, log, callback) {
    const handleException = async () => {
        clearInterval(terminalStatusInterval);
        if (terminalCloseEvent) {
            terminalCloseEvent.dispose();
        }
        // 非正常退出时才做处理
        if (ssh2Tools.status === 'connected') {
            let results;
            try {
                results = await ssh2Tools.clear(fileList, 3);
            }
            catch (err) {
                results = fileList.map(item => ({ item, error: 'sftp connected failed' }));
            }
            results.forEach((result) => {
                log(result.filePath + ': ' + result.error || 'success');
            });
            callback('terminal exception failed');
        }
    };
    let sshIsStart = false;
    clearInterval(terminalStatusInterval);
    if (terminalCloseEvent) {
        terminalCloseEvent.dispose();
    }
    terminalStatusInterval = setInterval(() => {
        if (terminal.name === 'ssh') {
            sshIsStart = true;
        }
        if (sshIsStart && terminal.name !== 'ssh') {
            handleException();
        }
    }, 100);
    terminalCloseEvent = vscode.window.onDidCloseTerminal(async (t) => {
        const currProcessId = await t.processId;
        const processId = await terminal.processId;
        if (currProcessId === processId) {
            handleException();
        }
    });
}
//# sourceMappingURL=webview-msg-handler.js.map